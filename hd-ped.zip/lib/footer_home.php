		<!-- Start JS -->
		<script src="<?php echo $config['web']['url'] ?>assets/js/pages/custom/login/jquery-2.2.0.min.js"></script>
		<script src="<?php echo $config['web']['url'] ?>assets/js/pages/custom/login/popper.min.js"></script>
		<script src="<?php echo $config['web']['url'] ?>assets/js/pages/custom/login/bootstrap.min.js"></script>
		<!-- End JS -->

		</body>
</html>