<?php
//Pengaturan Website
$config['web'] = array(
	'url' => 'https://winstore.site/' // ex: http://domain.com/
);
?>
