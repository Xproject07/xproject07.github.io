<?php
header("location: /");
?>